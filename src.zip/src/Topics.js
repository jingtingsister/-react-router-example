import React from 'react';

const Topics = ({pathname}) => {
    return (
        <div>
            <h2>Topics</h2>
            {pathname}
        </div>
    );
};

export default Topics;
